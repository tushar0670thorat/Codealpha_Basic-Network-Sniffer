"""
Filtered Packet Sniffer - Capture specific traffic types
Useful for monitoring specific protocols or traffic patterns
"""

from scapy.all import sniff, IP, TCP, UDP, ICMP, DNS, DNSQR, Raw
from datetime import datetime

class FilteredSniffer:
    """Capture and display filtered packet types."""
    
    def __init__(self, filter_type="all", packet_count=0):
        """
        Initialize filtered sniffer.
        
        Args:
            filter_type: 'tcp', 'udp', 'icmp', 'dns', 'http', 'https', 'arp', 'all'
            packet_count: Number of packets to capture (0 = infinite)
        """
        self.filter_type = filter_type
        self.packet_count = packet_count
        self.captured = 0
        
    def start(self):
        """Start capturing filtered packets."""
        filter_map = {
            'tcp': 'tcp',
            'udp': 'udp',
            'icmp': 'icmp',
            'dns': 'udp port 53',
            'http': 'tcp port 80',
            'https': 'tcp port 443',
            'arp': 'arp',
        }
        
        bpf_filter = filter_map.get(self.filter_type, "")
        
        print(f"\n{'='*70}")
        print(f"🔍 Filtered Packet Sniffer - {self.filter_type.upper()}")
        print(f"{'='*70}")
        print(f"Filter: {bpf_filter if bpf_filter else 'No filter (all packets)'}")
        print("Press Ctrl+C to stop...\n")
        
        try:
            sniff(
                prn=self.display_packet,
                filter=bpf_filter if bpf_filter else None,
                count=self.packet_count,
                store=False
            )
        except KeyboardInterrupt:
            print(f"\n✋ Stopped. Captured {self.captured} packets.")
        except PermissionError:
            print("❌ Error: Requires root/administrator privileges!")
    
    def display_packet(self, packet):
        """Display filtered packet information."""
        self.captured += 1
        timestamp = datetime.now().strftime('%H:%M:%S.%f')[:-3]
        
        print(f"\n[{timestamp}] Packet #{self.captured}")
        print("-" * 70)
        
        if self.filter_type == 'dns':
            self.display_dns_packet(packet)
        elif self.filter_type == 'http':
            self.display_http_packet(packet)
        elif self.filter_type == 'https':
            self.display_https_packet(packet)
        else:
            self.display_generic_packet(packet)
    
    @staticmethod
    def display_dns_packet(packet):
        """Display DNS packet details."""
        if IP in packet and packet[IP].sport == 53 or packet[IP].dport == 53:
            ip_layer = packet[IP]
            print(f"Source: {ip_layer.src} → Destination: {ip_layer.dst}")
            
            if DNSQR in packet:
                dns_query = packet[DNSQR]
                print(f"🔍 DNS Query: {dns_query.qname.decode('utf-8', errors='ignore')}")
            elif DNS in packet:
                dns_layer = packet[DNS]
                print(f"DNS ID: {dns_layer.id}")
                print(f"DNS Response: {dns_layer.an}")
    
    @staticmethod
    def display_http_packet(packet):
        """Display HTTP packet details."""
        if IP in packet and TCP in packet:
            ip_layer = packet[IP]
            tcp_layer = packet[TCP]
            print(f"Source: {ip_layer.src}:{tcp_layer.sport}")
            print(f"Destination: {ip_layer.dst}:{tcp_layer.dport}")
            
            if Raw in packet:
                payload = packet[Raw].load
                try:
                    http_data = payload.decode('utf-8', errors='ignore')
                    if 'HTTP' in http_data or 'GET' in http_data or 'POST' in http_data:
                        lines = http_data.split('\r\n')[:5]
                        for line in lines:
                            if line:
                                print(f"  {line}")
                except:
                    print(f"  Payload (hex): {payload[:50].hex()}...")
    
    @staticmethod
    def display_https_packet(packet):
        """Display HTTPS packet details."""
        if IP in packet and TCP in packet:
            ip_layer = packet[IP]
            tcp_layer = packet[TCP]
            print(f"Source: {ip_layer.src}:{tcp_layer.sport}")
            print(f"Destination: {ip_layer.dst}:{tcp_layer.dport}")
            print(f"🔒 HTTPS/TLS Traffic (encrypted)")
            if TCP in packet:
                flags = packet[TCP].flags
                print(f"  TCP Flags: {flags}")
    
    @staticmethod
    def display_generic_packet(packet):
        """Display generic packet information."""
        if IP in packet:
            ip_layer = packet[IP]
            print(f"Source IP: {ip_layer.src}")
            print(f"Destination IP: {ip_layer.dst}")
            print(f"Protocol: {ip_layer.proto}")
            
            if TCP in packet:
                tcp_layer = packet[TCP]
                print(f"Ports: {tcp_layer.sport} → {tcp_layer.dport}")
            elif UDP in packet:
                udp_layer = packet[UDP]
                print(f"Ports: {udp_layer.sport} → {udp_layer.dport}")


if __name__ == "__main__":
    # Example usage - uncomment one:
    
    # sniffer = FilteredSniffer(filter_type='tcp', packet_count=10)
    # sniffer = FilteredSniffer(filter_type='dns', packet_count=10)
    # sniffer = FilteredSniffer(filter_type='http', packet_count=10)
    sniffer = FilteredSniffer(filter_type='all', packet_count=0)
    
    sniffer.start()