M"""
Network Packet Sniffer - Core Module
Captures and displays network traffic packets with detailed analysis
"""

from scapy.all import sniff, IP, TCP, UDP, ICMP, ARP, Raw, IPv6
from datetime import datetime
import sys

class PacketSniffer:
    """Main packet sniffer class for capturing and analyzing network traffic."""
    
    def __init__(self, packet_count=0, interface=None, packet_filter=""):
        """
        Initialize the packet sniffer.
        
        Args:
            packet_count: Number of packets to capture (0 = infinite)
            interface: Network interface to sniff on (None = all)
            packet_filter: BPF filter (e.g., "tcp port 80")
        """
        self.packet_count = packet_count
        self.interface = interface
        self.packet_filter = packet_filter
        self.packet_number = 0
        
    def start(self):
        """Start capturing packets."""
        try:
            print(f"\n{'='*70}")
            print("🔍 Network Packet Sniffer Started")
            print(f"{'='*70}")
            print(f"Capture Mode: {'Limited to {}'.format(self.packet_count) if self.packet_count else 'Continuous'}")
            if self.interface:
                print(f"Interface: {self.interface}")
            if self.packet_filter:
                print(f"Filter: {self.packet_filter}")
            print(f"{'='*70}\n")
            print("Press Ctrl+C to stop capturing...\n")
            
            sniff(
                prn=self.packet_callback,
                iface=self.interface,
                filter=self.packet_filter,
                count=self.packet_count,
                store=False
            )
        except PermissionError:
            print("❌ Error: This script requires root/administrator privileges!")
            print("Run with: sudo python3 packet_sniffer.py")
            sys.exit(1)
        except KeyboardInterrupt:
            print(f"\n\n{'='*70}")
            print(f"✋ Capture stopped. Total packets captured: {self.packet_number}")
            print(f"{'='*70}\n")
        except Exception as e:
            print(f"❌ Error: {str(e)}")
            sys.exit(1)
    
    def packet_callback(self, packet):
        """Process each captured packet."""
        self.packet_number += 1
        print(f"\n[Packet #{self.packet_number}] {datetime.now().strftime('%H:%M:%S.%f')[:-3]}")
        print("-" * 70)
        
        # Display Layer 2 (Ethernet/MAC) info
        self.display_mac_info(packet)
        
        # Display Layer 3 (IP) info
        self.display_ip_info(packet)
        
        # Display Layer 4 (Transport) info
        self.display_transport_info(packet)
        
        # Display Payload
        self.display_payload(packet)
    
    @staticmethod
    def display_mac_info(packet):
        """Display MAC layer information."""
        if packet.haslayer('Ethernet'):
            mac_src = packet['Ethernet'].src
            mac_dst = packet['Ethernet'].dst
            print(f"🔗 MAC Layer (Layer 2):")
            print(f"   Source MAC:      {mac_src}")
            print(f"   Destination MAC: {mac_dst}")
    
    @staticmethod
    def display_ip_info(packet):
        """Display IP layer information."""
        if IP in packet:
            ip_layer = packet[IP]
            print(f"🌐 IP Layer (Layer 3):")
            print(f"   Version:         {ip_layer.version}")
            print(f"   Header Length:   {ip_layer.ihl * 4} bytes")
            print(f"   TTL:             {ip_layer.ttl}")
            print(f"   Total Length:    {ip_layer.len} bytes")
            print(f"   Source IP:       {ip_layer.src}")
            print(f"   Destination IP:  {ip_layer.dst}")
            
            # Protocol identification
            protocol_map = {
                1: "ICMP",
                6: "TCP",
                17: "UDP",
            }
            protocol_name = protocol_map.get(ip_layer.proto, f"Other({ip_layer.proto})")
            print(f"   Protocol:        {protocol_name}")
            print(f"   Flags:           {ip_layer.flags}")
            print(f"   Fragment Offset: {ip_layer.frag}")
        
        elif IPv6 in packet:
            ipv6_layer = packet[IPv6]
            print(f"🌐 IPv6 Layer (Layer 3):")
            print(f"   Version:         {ipv6_layer.version}")
            print(f"   Traffic Class:   {ipv6_layer.tc}")
            print(f"   Flow Label:      {ipv6_layer.fl}")
            print(f"   Source IP:       {ipv6_layer.src}")
            print(f"   Destination IP:  {ipv6_layer.dst}")
            print(f"   Next Header:     {ipv6_layer.nxt}")
    
    @staticmethod
    def display_transport_info(packet):
        """Display Transport layer information."""
        if TCP in packet:
            tcp_layer = packet[TCP]
            print(f"📤 TCP Layer (Layer 4):")
            print(f"   Source Port:     {tcp_layer.sport}")
            print(f"   Destination Port:{tcp_layer.dport}")
            print(f"   Sequence Number: {tcp_layer.seq}")
            print(f"   Acknowledgment:  {tcp_layer.ack}")
            print(f"   Flags:           {tcp_layer.flags}")
            print(f"   Window Size:     {tcp_layer.window}")
            print(f"   Checksum:        {tcp_layer.chksum}")
        
        elif UDP in packet:
            udp_layer = packet[UDP]
            print(f"📤 UDP Layer (Layer 4):")
            print(f"   Source Port:     {udp_layer.sport}")
            print(f"   Destination Port:{udp_layer.dport}")
            print(f"   Length:          {udp_layer.len}")
            print(f"   Checksum:        {udp_layer.chksum}")
        
        elif ICMP in packet:
            icmp_layer = packet[ICMP]
            print(f"📤 ICMP Layer (Layer 4):")
            print(f"   Type:            {icmp_layer.type}")
            print(f"   Code:            {icmp_layer.code}")
            print(f"   Checksum:        {icmp_layer.chksum}")
        
        elif ARP in packet:
            arp_layer = packet[ARP]
            print(f"🔗 ARP Layer:")
            print(f"   Operation:       {'Request' if arp_layer.op == 1 else 'Reply'}")
            print(f"   Source MAC:      {arp_layer.hwsrc}")
            print(f"   Source IP:       {arp_layer.psrc}")
            print(f"   Target MAC:      {arp_layer.hwdst}")
            print(f"   Target IP:       {arp_layer.pdst}")
    
    @staticmethod
    def display_payload(packet):
        """Display packet payload information."""
        if Raw in packet:
            payload = packet[Raw].load
            payload_size = len(payload)
            print(f"📦 Payload:")
            print(f"   Size:            {payload_size} bytes")
            
            # Try to decode as text if possible
            try:
                decoded = payload.decode('utf-8', errors='ignore')
                if len(decoded) > 0 and len(decoded) < 500:
                    print(f"   Data (Text):     {decoded[:200]}")
                else:
                    print(f"   Data (Hex):      {payload[:100].hex()[:100]}...")
            except:
                print(f"   Data (Hex):      {payload[:100].hex()[:100]}...")
        else:
            print(f"📦 Payload: None (Header-only packet)")


if __name__ == "__main__":
    # Default configuration
    PACKET_COUNT = 0  # 0 = infinite
    INTERFACE = None  # None = all interfaces
    FILTER = ""  # Empty string = no filter
    
    # Example filters:
    # FILTER = "tcp port 80"
    # FILTER = "udp"
    # FILTER = "icmp"
    # FILTER = "host 192.168.1.100"
    
    sniffer = PacketSniffer(
        packet_count=PACKET_COUNT,
        interface=INTERFACE,
        packet_filter=FILTER
    )
    
    sniffer.start()