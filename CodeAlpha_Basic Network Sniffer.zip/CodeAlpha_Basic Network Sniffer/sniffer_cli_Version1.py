"""
Interactive CLI for Network Packet Sniffer
Provides user-friendly menu-driven interface
"""

import sys
from packet_sniffer import PacketSniffer
from packet_analyzer import PacketAnalyzer
from filtered_sniffer import FilteredSniffer

class SnifferCLI:
    """Interactive command-line interface for packet sniffing."""
    
    def __init__(self):
        self.running = True
    
    def display_menu(self):
        """Display main menu."""
        print(f"\n{'='*70}")
        print("🌐 NETWORK PACKET SNIFFER - Interactive CLI")
        print(f"{'='*70}")
        print("\n1. 🔍 Basic Packet Sniffer")
        print("   - Capture and display packets with full details")
        print("\n2. 📊 Advanced Analyzer")
        print("   - Analyze packets and generate statistics")
        print("\n3. 🎯 Filtered Sniffer")
        print("   - Capture specific protocol types (TCP, UDP, DNS, HTTP, etc.)")
        print("\n4. ⚙️  Custom Sniffer")
        print("   - Configure custom filters and options")
        print("\n5. ℹ️  Protocol Reference")
        print("   - Display protocol information guide")
        print("\n6. ❌ Exit")
        print(f"\n{'='*70}")
    
    def run(self):
        """Run the CLI."""
        while self.running:
            self.display_menu()
            choice = input("\nEnter your choice (1-6): ").strip()
            
            if choice == '1':
                self.basic_sniffer()
            elif choice == '2':
                self.analyzer()
            elif choice == '3':
                self.filtered_sniffer()
            elif choice == '4':
                self.custom_sniffer()
            elif choice == '5':
                self.protocol_reference()
            elif choice == '6':
                print("\n👋 Goodbye!\n")
                self.running = False
            else:
                print("❌ Invalid choice. Please try again.")
    
    @staticmethod
    def basic_sniffer():
        """Run basic packet sniffer."""
        print("\n" + "="*70)
        print("Basic Packet Sniffer")
        print("="*70)
        
        try:
            count = input("Number of packets to capture (0 for infinite): ").strip()
            count = int(count) if count.isdigit() else 0
            
            sniffer = PacketSniffer(packet_count=count)
            sniffer.start()
        except ValueError:
            print("❌ Invalid input. Using default (infinite).")
            sniffer = PacketSniffer()
            sniffer.start()
    
    @staticmethod
    def analyzer():
        """Run packet analyzer."""
        print("\n" + "="*70)
        print("Advanced Packet Analyzer")
        print("="*70)
        
        try:
            count = input("Number of packets to analyze (default 100): ").strip()
            count = int(count) if count.isdigit() else 100
            
            analyzer = PacketAnalyzer(packet_count=count)
            analyzer.start()
        except ValueError:
            print("❌ Invalid input. Using default (100 packets).")
            analyzer = PacketAnalyzer()
            analyzer.start()
    
    @staticmethod
    def filtered_sniffer():
        """Run filtered sniffer."""
        print("\n" + "="*70)
        print("Filtered Packet Sniffer")
        print("="*70)
        
        print("\nAvailable filters:")
        filters = ['tcp', 'udp', 'icmp', 'dns', 'http', 'https', 'arp', 'all']
        for i, f in enumerate(filters, 1):
            print(f"  {i}. {f.upper()}")
        
        try:
            choice = int(input("\nSelect filter (1-8): ").strip()) - 1
            if 0 <= choice < len(filters):
                filter_type = filters[choice]
                
                count = input("Number of packets to capture (0 for infinite): ").strip()
                count = int(count) if count.isdigit() else 0
                
                sniffer = FilteredSniffer(filter_type=filter_type, packet_count=count)
                sniffer.start()
            else:
                print("❌ Invalid choice.")
        except ValueError:
            print("❌ Invalid input.")
    
    @staticmethod
    def custom_sniffer():
        """Run custom sniffer with BPF filter."""
        print("\n" + "="*70)
        print("Custom Sniffer with BPF Filters")
        print("="*70)
        
        print("\nBPF Filter Examples:")
        print("  tcp port 80          - HTTP traffic")
        print("  udp port 53          - DNS traffic")
        print("  host 192.168.1.1     - Traffic to/from specific IP")
        print("  src 192.168.1.0/24   - Traffic from specific subnet")
        print("  tcp and dst port 443 - HTTPS traffic")
        print("  not icmp             - Exclude ICMP (ping)")
        
        try:
            bpf_filter = input("\nEnter BPF filter (or press Enter for no filter): ").strip()
            count = input("Number of packets to capture (0 for infinite): ").strip()
            count = int(count) if count.isdigit() else 0
            
            sniffer = PacketSniffer(
                packet_count=count,
                packet_filter=bpf_filter if bpf_filter else ""
            )
            sniffer.start()
        except ValueError:
            print("❌ Invalid input.")
    
    @staticmethod
    def protocol_reference():
        """Display protocol reference information."""
        print("\n" + "="*70)
        print("📚 PROTOCOL REFERENCE GUIDE")
        print("="*70)
        
        reference = """
NETWORK PROTOCOL LAYERS (OSI Model):

Layer 1 - Physical: Raw bit transmission (cables, signals)
Layer 2 - Data Link: MAC addresses, Ethernet, ARP
  • ARP (Address Resolution Protocol) - MAC address resolution
  • Ethernet - Local network communication

Layer 3 - Network: IP addresses, routing
  • IP (Internet Protocol) - Packet routing
  • ICMP (Internet Control Message Protocol) - Ping, traceroute
  • IPv6 - Next-generation IP

Layer 4 - Transport: End-to-end communication
  • TCP (Transmission Control Protocol) - Reliable, ordered delivery
  • UDP (User Datagram Protocol) - Fast, unreliable delivery

Layer 5-7 - Application: User services
  • HTTP/HTTPS - Web browsing
  • DNS - Domain name resolution
  • FTP - File transfer
  • SSH - Secure shell
  • SMTP/POP3 - Email

KEY CONCEPTS:

Port Numbers:
  • 0-1023: Well-known ports (HTTP=80, HTTPS=443, SSH=22)
  • 1024-49151: Registered ports
  • 49152-65535: Dynamic/private ports

TCP Flags:
  • SYN - Synchronize (connection start)
  • ACK - Acknowledgment
  • FIN - Finish (connection end)
  • RST - Reset
  • PSH - Push (send data immediately)
  • URG - Urgent

COMMON PACKET FLOWS:

TCP Connection (3-way handshake):
  1. Client sends SYN
  2. Server responds with SYN-ACK
  3. Client sends ACK
  4. Data exchange
  5. Either party sends FIN to close

UDP Communication (connectionless):
  • Client sends data
  • Server receives and optionally responds
  • No connection establishment

DNS Query:
  • Client sends UDP port 53 query
  • Server responds with DNS answer

HTTP Request:
  • Client sends HTTP request on TCP port 80
  • Server sends HTTP response

ANALYZING PACKET STRUCTURE:

Each packet typically contains:
  1. Ethernet Header (MAC addressing)
  2. IP Header (IP addressing, routing)
  3. TCP/UDP Header (ports, control info)
  4. Application Data (payload)
        """
        
        print(reference)
        input("\nPress Enter to continue...")


def main():
    """Main entry point."""
    try:
        cli = SnifferCLI()
        cli.run()
    except KeyboardInterrupt:
        print("\n\n👋 Program interrupted. Goodbye!\n")
        sys.exit(0)
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()