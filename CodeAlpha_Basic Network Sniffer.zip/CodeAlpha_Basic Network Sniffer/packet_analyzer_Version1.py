"""
Advanced Packet Analyzer - Statistical Analysis Module
Provides deeper insights into captured packets
"""

from scapy.all import sniff, IP, TCP, UDP, ICMP, ARP, Raw
from collections import defaultdict, Counter
import json
from datetime import datetime

class PacketAnalyzer:
    """Analyze captured packets and generate statistics."""
    
    def __init__(self, packet_count=100, interface=None):
        self.packet_count = packet_count
        self.interface = interface
        self.packets_captured = 0
        
        # Statistics tracking
        self.protocol_stats = Counter()
        self.ip_sources = Counter()
        self.ip_destinations = Counter()
        self.port_stats = defaultdict(lambda: {'tcp': 0, 'udp': 0})
        self.packet_sizes = []
        self.tcp_flags = Counter()
        
    def start(self):
        """Start packet analysis."""
        print(f"\n{'='*70}")
        print("📊 Advanced Packet Analyzer Started")
        print(f"{'='*70}")
        print(f"Capturing {self.packet_count} packets for analysis...\n")
        
        try:
            sniff(
                prn=self.analyze_packet,
                iface=self.interface,
                count=self.packet_count,
                store=False
            )
            self.display_statistics()
        except PermissionError:
            print("❌ Error: This script requires root/administrator privileges!")
        except KeyboardInterrupt:
            print("\n✋ Analysis stopped.")
            self.display_statistics()
    
    def analyze_packet(self, packet):
        """Analyze a single packet."""
        self.packets_captured += 1
        
        # Basic packet info
        if IP in packet:
            ip_layer = packet[IP]
            self.protocol_stats[self._get_protocol_name(ip_layer.proto)] += 1
            self.ip_sources[ip_layer.src] += 1
            self.ip_destinations[ip_layer.dst] += 1
            self.packet_sizes.append(len(packet))
            
            # TCP/UDP analysis
            if TCP in packet:
                tcp_layer = packet[TCP]
                self.port_stats[tcp_layer.dport]['tcp'] += 1
                self.tcp_flags[str(tcp_layer.flags)] += 1
            
            elif UDP in packet:
                udp_layer = packet[UDP]
                self.port_stats[udp_layer.dport]['udp'] += 1
    
    @staticmethod
    def _get_protocol_name(proto_num):
        """Convert protocol number to name."""
        protocol_map = {
            1: "ICMP",
            6: "TCP",
            17: "UDP",
            41: "IPv6",
        }
        return protocol_map.get(proto_num, f"Other({proto_num})")
    
    def display_statistics(self):
        """Display analysis statistics."""
        print(f"\n\n{'='*70}")
        print("📈 PACKET ANALYSIS STATISTICS")
        print(f"{'='*70}\n")
        
        print(f"Total Packets Captured: {self.packets_captured}\n")
        
        # Protocol breakdown
        print("Protocol Distribution:")
        print("-" * 70)
        for protocol, count in self.protocol_stats.most_common():
            percentage = (count / self.packets_captured * 100) if self.packets_captured > 0 else 0
            print(f"  {protocol:<15} {count:>5} packets ({percentage:>5.1f}%)")
        
        # Packet sizes
        if self.packet_sizes:
            print(f"\nPacket Size Statistics:")
            print("-" * 70)
            print(f"  Average Size:    {sum(self.packet_sizes) / len(self.packet_sizes):.2f} bytes")
            print(f"  Minimum Size:    {min(self.packet_sizes)} bytes")
            print(f"  Maximum Size:    {max(self.packet_sizes)} bytes")
        
        # Top source IPs
        print(f"\nTop 5 Source IP Addresses:")
        print("-" * 70)
        for ip, count in self.ip_sources.most_common(5):
            percentage = (count / self.packets_captured * 100) if self.packets_captured > 0 else 0
            print(f"  {ip:<20} {count:>5} packets ({percentage:>5.1f}%)")
        
        # Top destination IPs
        print(f"\nTop 5 Destination IP Addresses:")
        print("-" * 70)
        for ip, count in self.ip_destinations.most_common(5):
            percentage = (count / self.packets_captured * 100) if self.packets_captured > 0 else 0
            print(f"  {ip:<20} {count:>5} packets ({percentage:>5.1f}%)")
        
        # Top destination ports
        if self.port_stats:
            print(f"\nTop 10 Destination Ports:")
            print("-" * 70)
            sorted_ports = sorted(
                self.port_stats.items(),
                key=lambda x: x[1]['tcp'] + x[1]['udp'],
                reverse=True
            )
            for port, protocols in sorted_ports[:10]:
                total = protocols['tcp'] + protocols['udp']
                print(f"  Port {port:<5} - TCP: {protocols['tcp']:>3}, UDP: {protocols['udp']:>3} (Total: {total})")
        
        # TCP Flags
        if self.tcp_flags:
            print(f"\nTCP Flags Encountered:")
            print("-" * 70)
            for flags, count in self.tcp_flags.most_common(5):
                print(f"  {flags:<10} {count:>5} times")
        
        print(f"\n{'='*70}\n")


if __name__ == "__main__":
    analyzer = PacketAnalyzer(packet_count=100)
    analyzer.start()